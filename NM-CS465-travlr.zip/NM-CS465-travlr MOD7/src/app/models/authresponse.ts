export class AuthResponse {
    token: string | undefined;
    }
