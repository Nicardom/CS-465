export class User {
    email: string | undefined;
    name: string | undefined;
}
